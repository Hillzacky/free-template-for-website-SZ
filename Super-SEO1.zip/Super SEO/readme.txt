
-----------------DOCUMENTATION--------------------

To change Social Icon links
---------------------------

Find the following code in the HTML:
<div class='right'>
<a class='iconFacebook' href='#'> Facebook </ a>
<a class='iconTwitter' href='#'> Twitter </ a>
<a class='iconRSS' href='#'> RSS </ a>
<a class='iconGoogle' href='#'> Google </ a>  
      </ div>

replace # with the URL of facebook, twitter, RSS and Google + Menu To edit the menu, find and edit its code


Menu Navigation changes
-----------------------

<- Menu START ->
<div id='navbarsecond'>
<ul class='dropdown' id='secondmenu'>
<li> <a href='/'> Home </ a> </ li>
<li> <a href=''> World News </ a> </ li>
<li> <a href=''> Entertainment </ a> </ li>
<li> <a href=''> Health </ a> </ li>
<li> <a href=''> Technology </ a> </ li>
<li> <a href=''> Auto </ a> </ li>
<li> <a class='sf-with-ul' href=''> Sport </ a>
<ul class='sub-menu'>
<li> <a href=''> Soccer </ a> </ li>
<li> <a href=''> Formula 1 </ a> </ li>
<li> <a href=''> Rally Racing </ a> </ li>
<li> <a href=''> Golf </ a> </ li>
</ Ul>
</ Li>
</ Ul>
<div class='clear'/>
</ Div> <! - / # Navbarsecond ->

