

Note: If your slider is not working then just upload the file from Javascript folder on any server and link that file into your blogger template and it will work.