var numposts = 5;
var showpostthumbnails = true;
var showpostdate = true;
<script type="text/javascript" src="/feeds/posts/default/-/Sukses?orderby=updated&amp;alt=json-in-script&amp;callback=rcentbytag"></script>

var numposts : Isi dengan jumlah post yang ingin ditampilkan
var showpostthumbnails : Isi dengan true bila gambar ingin ditampilkan, isi false bila Anda ingin menghilangkan gambar
var showpostdate : Isi dengan true bila tanggal ingin ditampilkan, isi false bila Anda ingin menghilangkan tanggal
Untuk mengisi labelnya, silakan ganti kata Sukse pada kode ini dan ganti dengan label yang Anda maksud
<script type="text/javascript" src="/feeds/posts/default/-/Sukses?orderby=updated&amp;alt=json-in-script&amp;callback=rcentbytag"></script>
